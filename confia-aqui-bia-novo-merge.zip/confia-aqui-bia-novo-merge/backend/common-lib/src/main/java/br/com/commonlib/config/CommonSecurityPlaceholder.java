package br.com.commonlib.config;

public final class CommonSecurityPlaceholder {
    private CommonSecurityPlaceholder() {
        // Construtor privado para evitar instanciação
    }
}
