package br.com.commonlib;

public class Common {
    public static void main(String[] args) {
       
    }
}