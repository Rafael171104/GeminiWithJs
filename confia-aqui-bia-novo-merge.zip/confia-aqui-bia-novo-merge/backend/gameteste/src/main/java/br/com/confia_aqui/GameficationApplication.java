package br.com.confia_aqui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameficationApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameficationApplication.class, args);
	}

}
