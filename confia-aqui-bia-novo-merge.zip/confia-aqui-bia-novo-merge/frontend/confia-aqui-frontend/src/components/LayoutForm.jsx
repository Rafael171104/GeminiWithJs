function LayoutForm(imagemLayoutForm, alt){
    return (
            <img src={imagemLayoutForm} alt={alt} />
    )
}

export default LayoutForm